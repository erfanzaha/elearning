<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['migration_enabled'] = TRUE;

$config['migration_type'] = 'timestamp';

$config['migration_table'] = 'migrations451';

$config['migration_auto_latest'] = FALSE;


$config['migration_version'] = 20211010100545;

$config['migration_path'] = APPPATH.'migrations4/';
